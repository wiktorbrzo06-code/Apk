# brak dodatkowych reguł – minifikacja wyłączona
