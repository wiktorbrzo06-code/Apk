# Pocket AI Analyzer – Android (WebView)

Prosta aplikacja Android otwierająca Twoją stronę `app/src/main/assets/index.html`
w pełnoekranowym WebView. Strona jest zapakowana w aplikacji (działa offline).

## Jak zbudować APK

### A) Bez komputera – GitHub Actions (darmowe)
1. Załóż konto na github.com i utwórz nowe repozytorium.
2. Wgraj całą zawartość tego folderu (razem z ukrytym folderem `.github`).
3. Wejdź w **Actions → Build APK → Run workflow**.
4. Po kilku minutach pobierz plik z sekcji **Artifacts** (`PocketAIAnalyzer-debug-apk`),
   rozpakuj ZIP i zainstaluj `app-debug.apk` (Android poprosi o zgodę na instalację z nieznanych źródeł).

### B) Android Studio (komputer)
Otwórz folder, poczekaj na synchronizację Gradle, potem **Build → Build APK(s)**.
Plik: `app/build/outputs/apk/debug/app-debug.apk`.

### C) Wiersz poleceń (JDK 17 + Android SDK + Gradle 8.9)
`gradle assembleDebug`

## Aktualizacja strony
Podmień `app/src/main/assets/index.html` nowszą wersją i zbuduj APK ponownie.

## Ograniczenia
- Silnik „AI (Claude)” działa tylko na stronie claude.ai. W APK używany jest silnik lokalny (bez API, offline).
- Eksport CSV korzysta z funkcji claude.ai – w APK nie zapisze pliku (do dopisania osobno).
- APK „debug” wystarcza do własnego użytku. Do Google Play potrzebny jest podpisany build release.
- Aby ładować stronę z internetu, zmień `START_URL` w `app/build.gradle.kts`.
